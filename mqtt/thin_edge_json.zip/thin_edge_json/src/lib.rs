use json::JsonValue;

pub struct ThinEdgeJson {
    // unimplemented
}

pub struct CumulocityJson {
    // unimplemented
}

#[derive(Debug, Eq, PartialEq)]
pub enum Error {
    InvalidUTF8,
    InvalidJson,
    InvalidThinEdgeJson,
}

impl ThinEdgeJson {
    pub fn from_json_string(input: &str) -> Result<ThinEdgeJson, Error> {
        unimplemented!();
    }

    pub fn from_json(input: &json::JsonValue) -> Result<ThinEdgeJson, Error> {
        unimplemented!();
    }

    // The time is given as a timestamp to simplify tests.
    pub fn into_cumulocity_json(&self, timestamp: &str) -> CumulocityJson {
        unimplemented!();
    }
}

impl CumulocityJson {
    pub fn from_json(input: &json::JsonValue) -> Result<CumulocityJson, Error> {
        unimplemented!();
    }

    pub fn into_json_string(&self) -> String {
        unimplemented!();
    }
}


#[cfg(test)]
mod tests {
    use crate::ThinEdgeJson;

    #[test]
    fn it_works() {
        let input = r#"{
            "temperature": 23,
            "pressure": 220
        }"#;

        let time = "2013-06-22T17:03:14.000+02:00";

        let expected_output = r#"{
            "time": "2013-06-22T17:03:14.000+02:00",
            "type": "ThinEdgeMeasurement",
            "temperatureMeasurement": {
                 "temperature": {
                     "value": 23
                 }
            },
            "pressureMeasurement": {
                 "pressure": {
                     "value": 220
                 }
            }
        }"#;

        let output =
            ThinEdgeJson::from_json_string(input)
                .unwrap()
                .into_cumulocity_json(time)
                .into_json_string();

        assert_eq!(
            output.split_whitespace().collect::<String>(),
            expected_output.split_whitespace().collect::<String>()
        );
    }

    use proptest::prelude::*;
    proptest! {
        #[test]
        fn it_works_for_any_measurement(measurement in r#"[a-z]{3,6}"#) {
            let input = format!(r#"{{
                "{}": 123
            }}"#, measurement);

            let time = "2013-06-22T17:03:14.000+02:00";

            let expected_output = format!(r#"{{
                "time": "2013-06-22T17:03:14.000+02:00",
                "type": "ThinEdgeMeasurement",
                "{}Measurement": {{
                     "{}": {{
                         "value": 123
                     }}
                }}
            }}"#, measurement, measurement);

            let output =
                ThinEdgeJson::from_json_string(&input)
                    .unwrap()
                    .into_cumulocity_json(time)
                    .into_json_string();

            assert_eq!(
                output.split_whitespace().collect::<String>(),
                expected_output.split_whitespace().collect::<String>()
            );
        }
    }
}
